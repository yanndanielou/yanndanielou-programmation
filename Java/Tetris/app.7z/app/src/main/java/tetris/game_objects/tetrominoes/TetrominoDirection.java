package tetris.game_objects.tetrominoes;

public enum TetrominoDirection {
	INITIAL_POSITION, ROTATED_90_DEGREES, ROTATED_180_DEGREES, ROTATED_270_DEGREES;
}
