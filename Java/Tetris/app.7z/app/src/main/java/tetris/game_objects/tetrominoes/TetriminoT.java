package tetris.game_objects.tetrominoes;

public class TetriminoT extends Tetromino {

	public TetriminoT() {
		// TODO Auto-generated constructor stub
	}

}
