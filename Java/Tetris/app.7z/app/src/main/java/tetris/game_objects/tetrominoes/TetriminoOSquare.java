package tetris.game_objects.tetrominoes;

public class TetriminoOSquare extends Tetromino {

	public TetriminoOSquare() {
		// TODO Auto-generated constructor stub
	}

}
