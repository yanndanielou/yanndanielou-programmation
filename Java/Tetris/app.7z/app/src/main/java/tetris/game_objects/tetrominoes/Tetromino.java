package tetris.game_objects.tetrominoes;

public abstract class Tetromino {
	
	protected TetrominoDirection direction;

	public Tetromino() {
		// TODO Auto-generated constructor stub
	}

}
