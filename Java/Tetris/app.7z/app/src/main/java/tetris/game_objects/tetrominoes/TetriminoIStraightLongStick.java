package tetris.game_objects.tetrominoes;

public class TetriminoIStraightLongStick extends Tetromino {

	public TetriminoIStraightLongStick() {
		// TODO Auto-generated constructor stub
	}

}
