module tictactoe {
	requires javafx.controls;
	
	opens tictactoeblueskin to javafx.graphics, javafx.fxml;
}
