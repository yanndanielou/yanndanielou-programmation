function SMT2_Data_mB
 
%-------------------------------------------------------------
%Appel des sous-fonctions pour chaque type d'objet 
%-------------------------------------------------------------
   recup_mB;

return
 
 
%***************************************************************
function recup_mB
% missions de base
%***************************************************************
 
   global SMT_mB SMT_mB_step SMT_nb_mB

   SMT_nb_mB = 27;

   SMT_mB = struct( ...
      'nom',{'Line_North_South','Line_East_South','Line_South_North','Line_South_East','Line_North_to_South',...
               'Line_East_to_South','Line_South_to_North','Line_South_to_East','Turnback North','Turnback South Track T1',...
               'Turnback South Track T2','Turnback East','Simple Mission with Switch','Fork_North_to_South','Fork_East_to_South',...
               'Fork_South_to_North','Fork_South_to_East','STA2_P1 -- STA4_P1','STA7_P1 -- STA4_P1','STA1 -> STA5 (Scn�ario 1 - Train 1 - Xlib = 0)',...
               'STA1 -> STA5 (Scn�ario 1 - Train 2/3/4 - Xlib = 0)','STA5 -> STA1 (Sc�nario 2 - Xlib=0) (Cas 2)','STA5 -> STA1 (Sc�nario 2 - Xlib=0) (Cas 1 & 3)','STA1 -> STA5 (Scn�ario 3 - Train 2 - Xlib = 0)','STA5 -> STA1 (Sc�nario 4 - Xlib=0) ',...
               'FLO -> GRA','GRA -> FLO'},...
      'num',{'1','2','3','4','5',...
               '6','7','8','9','10',...
               '11','12','13','14','15',...
               '16','17','18','19','20',...
               '21','22','23','24','25',...
               '26','27'},...
      'nb_steps',{13,11,13,11,7,...
               6,7,6,5,5,...
               5,5,3,6,6,...
               4,4,2,2,7,...
               7,7,7,6,6,...
               3,4},...
      'nb_me_a_derouler',{10,8,10,8,4,...
               3,4,3,3,3,...
               3,3,2,3,3,...
               2,2,1,1,4,...
               4,4,4,3,3,...
               2,2},...
      'pk_max',{8270,6270,8250,6250,4000,...
               3000,4000,3000,1250,1270,...
               1270,1250,270,3000,3000,...
               2000,2000,3000,1000,4000,...
               4000,4000,4000,4000,4000,...
               756,756}...
      );
   % Compl�ment avec les donn�es du 2e ordre
   SMT_mB_step = struct( ...
      'mE',{[1,2,3,4,19,20,5,8,9,10,-3,17,18],[13,14,4,19,20,5,11,12,-3,15,16],[5,8,9,10,17,18,1,2,3,4,-3,19,20],[5,11,12,15,16,13,14,4,-3,19,20],[1,2,3,4,-3,19,20],...
               [13,14,4,-3,19,20],[5,8,9,10,-3,17,18],[5,11,12,-3,15,16],[10,17,18,-3,1],[4,19,20,-3,5],...
               [4,21,22,-3,5],[12,15,16,-3,13],[21,22,-3],[2,3,4,-3,19,20],[13,14,4,-3,19,20],...
               [5,8,-3,9],[5,11,-3,12],[23,-3],[24,-3],[25,2,3,4,-3,19,20],...
               [25,2,3,4,-3,19,20],[5,26,27,10,-3,17,18],[5,26,28,30,-3,17,18],[25,2,31,-3,19,20],[32,9,10,-3,17,18],...
               [34,35,-3],[37,38,-3,39]},...
      'sens_dep_train',{[1,1,1,1,1,2,2,2,2,2,2,2,1],[1,1,1,1,2,2,2,2,2,2,1],[2,2,2,2,2,1,1,1,1,1,1,1,2],[2,2,2,2,1,1,1,1,1,1,2],[1,1,1,1,1,1,2],...
               [1,1,1,1,1,2],[2,2,2,2,2,2,1],[2,2,2,2,2,1],[2,2,1,1,1],[1,1,2,2,2],...
               [1,1,2,2,2],[2,2,1,1,1],[1,2,2],[1,1,1,1,1,2],[1,1,1,1,1,2],...
               [2,2,2,2],[2,2,2,2],[1,1],[1,1],[1,1,1,1,1,1,2],...
               [1,1,1,1,1,1,2],[2,2,2,2,2,2,1],[2,2,2,2,2,2,1],[1,1,1,1,1,2],[2,2,2,2,2,1],...
               [1,1,1],[2,2,2,2]},...
      'pk_debut',{[0,1000,2000,3000,4000,4135,4270,5270,6270,7270,8270,8270,8395],[0,1000,2000,3000,3135,3270,4270,5270,6270,6270,6395],[0,1000,2000,3000,4000,4125,4250,5250,6250,7250,8250,8250,8385],[0,1000,2000,3000,3125,3250,4250,5250,6250,6250,6385],[0,1000,2000,3000,4000,4000,4135],...
               [0,1000,2000,3000,3000,3135],[0,1000,2000,3000,4000,4000,4125],[0,1000,2000,3000,3000,3125],[0,1000,1125,1250,1250],[0,1000,1135,1270,1270],...
               [0,1000,1135,1270,1270],[0,1000,1125,1250,1250],[0,135,270],[0,1000,2000,3000,3000,3135],[0,1000,2000,3000,3000,3135],...
               [0,1000,2000,2000],[0,1000,2000,2000],[0,3000],[0,1000],[0,1000,2000,3000,4000,4000,4135],...
               [0,1000,2000,3000,4000,4000,4135],[0,1000,2000,3000,4000,4000,4125],[0,1000,2000,3000,4000,4000,4125],[0,1000,2000,4000,4000,4135],[0,2000,3000,4000,4000,4125],...
               [0,418,756],[0,338,756,756]},...
      'pk_fin',{[1015,2015,3015,4015,4150,4270,5285,6285,7285,8285,8285,8410,8520],[1015,2015,3015,3150,3270,4285,5285,6285,6285,6410,6520],[1015,2015,3015,4015,4140,4250,5265,6265,7265,8265,8265,8400,8520],[1015,2015,3015,3140,3250,4265,5265,6265,6265,6400,6520],[1015,2015,3015,4015,4015,4150,4270],...
               [1015,2015,3015,3015,3150,3270],[1015,2015,3015,4015,4015,4140,4250],[1015,2015,3015,3015,3140,3250],[1015,1140,1250,1250,2265],[1015,1150,1270,1270,2285],...
               [1015,1150,1270,1270,2285],[1015,1140,1250,1250,2265],[150,270,270],[1015,2015,3015,3015,3150,3270],[1015,2015,3015,3015,3150,3270],...
               [1015,2015,2015,3015],[1015,2015,2015,3015],[3015,3015],[1015,1015],[1015,2015,3015,4015,4015,4150,4270],...
               [1015,2015,3015,4015,4015,4150,4270],[1015,2015,3015,4015,4015,4140,4250],[1015,2015,3015,4015,4015,4140,4250],[1015,2015,4015,4015,4150,4270],[2015,3015,4015,4015,4140,4250],...
               [433,771,771],[353,771,771,1171]},...
      'cas_charge',{[3,3,3,3,1,1,3,3,3,3,1,1,1],[3,3,3,1,1,3,3,3,1,1,1],[3,3,3,3,1,1,3,3,3,3,1,1,1],[3,3,3,1,1,3,3,3,1,1,1],[3,3,3,3,1,1,1],...
               [3,3,3,1,1,1],[3,3,3,3,1,1,1],[3,3,3,1,1,1],[3,1,1,1,3],[3,1,1,1,3],...
               [3,1,1,1,3],[3,1,1,1,3],[1,1,1],[3,3,3,1,1,1],[3,3,3,1,1,1],...
               [3,3,1,3],[3,3,1,3],[3,1],[3,1],[3,3,3,3,1,1,1],...
               [3,3,3,3,1,1,1],[3,3,3,3,1,1,1],[3,3,3,3,1,1,1],[3,3,3,1,1,1],[3,3,3,1,1,1],...
               [1,1,1],[3,3,1,3]},...
      'type_marche',{[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0],...
               [0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],...
               [0,0,0,0,0],[0,0,0,0,0],[0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],...
               [0,0,0,0],[0,0,0,0],[0,0],[0,0],[0,0,0,0,0,0,0],...
               [0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],...
               [0,0,0],[0,0,0,0]},...
      'dwell_time',{[20,20,20,20,-20,20,20,20,20,20,1,-8,20],[20,20,20,-20,20,20,20,20,1,-8,20],[20,20,20,20,-8,20,20,20,20,20,1,-20,20],[20,20,20,-8,20,20,20,20,1,-20,20],[60,100,20,20,1,-20,20],...
               [20,20,20,1,-20,20],[20,20,20,20,1,-8,20],[20,20,20,1,-8,20],[20,-8,20,1,20],[20,-20,20,1,20],...
               [20,-20,20,1,20],[20,-8,20,1,20],[-2,2],[20,20,20,1,-20,20],[20,20,20,1,-20,20],...
               [20,20,1,20],[20,20,1,20],[2],[2],[100,20,20,20,1,-20,20],...
               [50,20,20,20,1,-20,20],[20,20,100,20,1,-8,20],[20,20,20,100,1,-8,20],[20,20,20,1,-20,20],[20,20,20,1,-8,20],...
               [30,30],[20,20,1,20]},...
      'anticip',{[1,1,1,1,1,1,1,1,1,1,0,1,1],[1,1,1,1,1,1,1,1,0,1,1],[1,1,1,1,1,1,1,1,1,1,0,1,1],[1,1,1,1,1,1,1,1,0,1,1],[1,1,1,1,0,1,1],...
               [1,1,1,0,1,1],[1,1,1,1,0,1,1],[1,1,1,0,1,1],[1,1,1,0,1],[1,1,1,0,1],...
               [1,1,1,0,1],[1,1,1,0,1],[0,1],[1,1,1,0,1,1],[1,1,1,0,1,1],...
               [1,1,0,1],[1,1,0,1],[0],[0],[1,1,1,1,0,1,1],...
               [1,1,1,1,0,1,1],[1,1,1,1,0,1,1],[1,1,1,1,0,1,1],[1,1,1,0,1,1],[1,1,1,0,1,1],...
               [0,0],[1,1,0,1]},...
      'type_sim',{[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0],...
               [0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],...
               [0,0,0,0,0],[0,0,0,0,0],[0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],...
               [0,0,0,0],[0,0,0,0],[0,0],[0,0],[0,0,0,0,0,0,0],...
               [0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],...
               [0,0,0],[0,0,0,0]},...
      'retard',{[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0],...
               [0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],...
               [0,0,0,0,0],[0,0,0,0,0],[0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],...
               [0,0,0,0],[0,0,0,0],[0,0],[0,0],[0,0,0,0,0,0,0],...
               [0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],...
               [0,0,0],[0,0,0,0]}...
      );
 
   global SMT_Nb_Choix_mE
   global SMT_Choix_mE_Deb_Index SMT_Choix_mE_Max_mE SMT_Choix_mE_Nb_mE SMT_Choix_mE_mE SMT_Choix_mE_Capteur SMT_Choix_mE_Abscisse
   global SMT_Nb_Choix_Capteur
   global SMT_Choix_Capteur_Nb_Choix
 
   SMT_Nb_Choix_mE = 0;
   SMT_Choix_mE_Deb_Index = 0;
   SMT_Choix_mE_Max_mE = 0;
   SMT_Choix_mE_Nb_mE = 0;
   SMT_Choix_mE_mE = 0;
   SMT_Choix_mE_Capteur = 0;
   SMT_Choix_mE_Abscisse = 0;

   SMT_Nb_Choix_Capteur = 0;
   SMT_Choix_Capteur_Nb_Choix = 0;

 
   SMT_mB_step(1).abs_me_coasting(1,1) = -1;
   SMT_mB_step(1).abs_me_coasting(1,2) = -1;
   SMT_mB_step(1).abs_me_coasting(3,1) = -1;
   SMT_mB_step(1).abs_me_coasting(3,2) = -1;
   SMT_mB_step(1).abs_me_coasting(5,1) = -1;
   SMT_mB_step(1).abs_me_coasting(5,2) = -1;
   SMT_mB_step(1).abs_me_coasting(7,1) = -1;
   SMT_mB_step(1).abs_me_coasting(7,2) = -1;
   SMT_mB_step(1).abs_me_coasting(9,1) = -1;
   SMT_mB_step(1).abs_me_coasting(9,2) = -1;
   SMT_mB_step(1).abs_me_coasting(11,1) = -1;
   SMT_mB_step(1).abs_me_coasting(11,2) = -1;
   SMT_mB_step(1).abs_me_coasting(13,1) = -1;
   SMT_mB_step(1).abs_me_coasting(13,2) = -1;
   SMT_mB_step(1).abs_me_coasting(15,1) = -1;
   SMT_mB_step(1).abs_me_coasting(15,2) = -1;
   SMT_mB_step(1).abs_me_coasting(17,1) = -1;
   SMT_mB_step(1).abs_me_coasting(17,2) = -1;
   SMT_mB_step(1).abs_me_coasting(19,1) = -1;
   SMT_mB_step(1).abs_me_coasting(19,2) = -1;
   SMT_mB_step(1).abs_me_coasting(21,1) = -1;
   SMT_mB_step(1).abs_me_coasting(21,2) = -1;
   SMT_mB_step(1).abs_me_coasting(22,1) = -1;
   SMT_mB_step(1).abs_me_coasting(22,2) = -1;
   SMT_mB_step(1).abs_me_coasting(24,1) = -1;
   SMT_mB_step(1).abs_me_coasting(24,2) = -1;
   SMT_mB_step(2).abs_me_coasting(1,1) = -1;
   SMT_mB_step(2).abs_me_coasting(1,2) = -1;
   SMT_mB_step(2).abs_me_coasting(3,1) = -1;
   SMT_mB_step(2).abs_me_coasting(3,2) = -1;
   SMT_mB_step(2).abs_me_coasting(5,1) = -1;
   SMT_mB_step(2).abs_me_coasting(5,2) = -1;
   SMT_mB_step(2).abs_me_coasting(7,1) = -1;
   SMT_mB_step(2).abs_me_coasting(7,2) = -1;
   SMT_mB_step(2).abs_me_coasting(9,1) = -1;
   SMT_mB_step(2).abs_me_coasting(9,2) = -1;
   SMT_mB_step(2).abs_me_coasting(11,1) = -1;
   SMT_mB_step(2).abs_me_coasting(11,2) = -1;
   SMT_mB_step(2).abs_me_coasting(13,1) = -1;
   SMT_mB_step(2).abs_me_coasting(13,2) = -1;
   SMT_mB_step(2).abs_me_coasting(15,1) = -1;
   SMT_mB_step(2).abs_me_coasting(15,2) = -1;
   SMT_mB_step(2).abs_me_coasting(17,1) = -1;
   SMT_mB_step(2).abs_me_coasting(17,2) = -1;
   SMT_mB_step(2).abs_me_coasting(18,1) = -1;
   SMT_mB_step(2).abs_me_coasting(18,2) = -1;
   SMT_mB_step(2).abs_me_coasting(20,1) = -1;
   SMT_mB_step(2).abs_me_coasting(20,2) = -1;
   SMT_mB_step(3).abs_me_coasting(1,1) = -1;
   SMT_mB_step(3).abs_me_coasting(1,2) = -1;
   SMT_mB_step(3).abs_me_coasting(3,1) = -1;
   SMT_mB_step(3).abs_me_coasting(3,2) = -1;
   SMT_mB_step(3).abs_me_coasting(5,1) = -1;
   SMT_mB_step(3).abs_me_coasting(5,2) = -1;
   SMT_mB_step(3).abs_me_coasting(7,1) = -1;
   SMT_mB_step(3).abs_me_coasting(7,2) = -1;
   SMT_mB_step(3).abs_me_coasting(9,1) = -1;
   SMT_mB_step(3).abs_me_coasting(9,2) = -1;
   SMT_mB_step(3).abs_me_coasting(11,1) = -1;
   SMT_mB_step(3).abs_me_coasting(11,2) = -1;
   SMT_mB_step(3).abs_me_coasting(13,1) = -1;
   SMT_mB_step(3).abs_me_coasting(13,2) = -1;
   SMT_mB_step(3).abs_me_coasting(15,1) = -1;
   SMT_mB_step(3).abs_me_coasting(15,2) = -1;
   SMT_mB_step(3).abs_me_coasting(17,1) = -1;
   SMT_mB_step(3).abs_me_coasting(17,2) = -1;
   SMT_mB_step(3).abs_me_coasting(19,1) = -1;
   SMT_mB_step(3).abs_me_coasting(19,2) = -1;
   SMT_mB_step(3).abs_me_coasting(21,1) = -1;
   SMT_mB_step(3).abs_me_coasting(21,2) = -1;
   SMT_mB_step(3).abs_me_coasting(22,1) = -1;
   SMT_mB_step(3).abs_me_coasting(22,2) = -1;
   SMT_mB_step(3).abs_me_coasting(24,1) = -1;
   SMT_mB_step(3).abs_me_coasting(24,2) = -1;
   SMT_mB_step(4).abs_me_coasting(1,1) = -1;
   SMT_mB_step(4).abs_me_coasting(1,2) = -1;
   SMT_mB_step(4).abs_me_coasting(3,1) = -1;
   SMT_mB_step(4).abs_me_coasting(3,2) = -1;
   SMT_mB_step(4).abs_me_coasting(5,1) = -1;
   SMT_mB_step(4).abs_me_coasting(5,2) = -1;
   SMT_mB_step(4).abs_me_coasting(7,1) = -1;
   SMT_mB_step(4).abs_me_coasting(7,2) = -1;
   SMT_mB_step(4).abs_me_coasting(9,1) = -1;
   SMT_mB_step(4).abs_me_coasting(9,2) = -1;
   SMT_mB_step(4).abs_me_coasting(11,1) = -1;
   SMT_mB_step(4).abs_me_coasting(11,2) = -1;
   SMT_mB_step(4).abs_me_coasting(13,1) = -1;
   SMT_mB_step(4).abs_me_coasting(13,2) = -1;
   SMT_mB_step(4).abs_me_coasting(15,1) = -1;
   SMT_mB_step(4).abs_me_coasting(15,2) = -1;
   SMT_mB_step(4).abs_me_coasting(17,1) = -1;
   SMT_mB_step(4).abs_me_coasting(17,2) = -1;
   SMT_mB_step(4).abs_me_coasting(18,1) = -1;
   SMT_mB_step(4).abs_me_coasting(18,2) = -1;
   SMT_mB_step(4).abs_me_coasting(20,1) = -1;
   SMT_mB_step(4).abs_me_coasting(20,2) = -1;
   SMT_mB_step(5).abs_me_coasting(1,1) = -1;
   SMT_mB_step(5).abs_me_coasting(1,2) = -1;
   SMT_mB_step(5).abs_me_coasting(3,1) = -1;
   SMT_mB_step(5).abs_me_coasting(3,2) = -1;
   SMT_mB_step(5).abs_me_coasting(5,1) = -1;
   SMT_mB_step(5).abs_me_coasting(5,2) = -1;
   SMT_mB_step(5).abs_me_coasting(7,1) = -1;
   SMT_mB_step(5).abs_me_coasting(7,2) = -1;
   SMT_mB_step(5).abs_me_coasting(9,1) = -1;
   SMT_mB_step(5).abs_me_coasting(9,2) = -1;
   SMT_mB_step(5).abs_me_coasting(10,1) = -1;
   SMT_mB_step(5).abs_me_coasting(10,2) = -1;
   SMT_mB_step(5).abs_me_coasting(12,1) = -1;
   SMT_mB_step(5).abs_me_coasting(12,2) = -1;
   SMT_mB_step(6).abs_me_coasting(1,1) = -1;
   SMT_mB_step(6).abs_me_coasting(1,2) = -1;
   SMT_mB_step(6).abs_me_coasting(3,1) = -1;
   SMT_mB_step(6).abs_me_coasting(3,2) = -1;
   SMT_mB_step(6).abs_me_coasting(5,1) = -1;
   SMT_mB_step(6).abs_me_coasting(5,2) = -1;
   SMT_mB_step(6).abs_me_coasting(7,1) = -1;
   SMT_mB_step(6).abs_me_coasting(7,2) = -1;
   SMT_mB_step(6).abs_me_coasting(8,1) = -1;
   SMT_mB_step(6).abs_me_coasting(8,2) = -1;
   SMT_mB_step(6).abs_me_coasting(10,1) = -1;
   SMT_mB_step(6).abs_me_coasting(10,2) = -1;
   SMT_mB_step(7).abs_me_coasting(1,1) = -1;
   SMT_mB_step(7).abs_me_coasting(1,2) = -1;
   SMT_mB_step(7).abs_me_coasting(3,1) = -1;
   SMT_mB_step(7).abs_me_coasting(3,2) = -1;
   SMT_mB_step(7).abs_me_coasting(5,1) = -1;
   SMT_mB_step(7).abs_me_coasting(5,2) = -1;
   SMT_mB_step(7).abs_me_coasting(7,1) = -1;
   SMT_mB_step(7).abs_me_coasting(7,2) = -1;
   SMT_mB_step(7).abs_me_coasting(9,1) = -1;
   SMT_mB_step(7).abs_me_coasting(9,2) = -1;
   SMT_mB_step(7).abs_me_coasting(10,1) = -1;
   SMT_mB_step(7).abs_me_coasting(10,2) = -1;
   SMT_mB_step(7).abs_me_coasting(12,1) = -1;
   SMT_mB_step(7).abs_me_coasting(12,2) = -1;
   SMT_mB_step(8).abs_me_coasting(1,1) = -1;
   SMT_mB_step(8).abs_me_coasting(1,2) = -1;
   SMT_mB_step(8).abs_me_coasting(3,1) = -1;
   SMT_mB_step(8).abs_me_coasting(3,2) = -1;
   SMT_mB_step(8).abs_me_coasting(5,1) = -1;
   SMT_mB_step(8).abs_me_coasting(5,2) = -1;
   SMT_mB_step(8).abs_me_coasting(7,1) = -1;
   SMT_mB_step(8).abs_me_coasting(7,2) = -1;
   SMT_mB_step(8).abs_me_coasting(8,1) = -1;
   SMT_mB_step(8).abs_me_coasting(8,2) = -1;
   SMT_mB_step(8).abs_me_coasting(10,1) = -1;
   SMT_mB_step(8).abs_me_coasting(10,2) = -1;
   SMT_mB_step(9).abs_me_coasting(1,1) = -1;
   SMT_mB_step(9).abs_me_coasting(1,2) = -1;
   SMT_mB_step(9).abs_me_coasting(3,1) = -1;
   SMT_mB_step(9).abs_me_coasting(3,2) = -1;
   SMT_mB_step(9).abs_me_coasting(5,1) = -1;
   SMT_mB_step(9).abs_me_coasting(5,2) = -1;
   SMT_mB_step(9).abs_me_coasting(7,1) = -1;
   SMT_mB_step(9).abs_me_coasting(7,2) = -1;
   SMT_mB_step(9).abs_me_coasting(8,1) = -1;
   SMT_mB_step(9).abs_me_coasting(8,2) = -1;
   SMT_mB_step(10).abs_me_coasting(1,1) = -1;
   SMT_mB_step(10).abs_me_coasting(1,2) = -1;
   SMT_mB_step(10).abs_me_coasting(3,1) = -1;
   SMT_mB_step(10).abs_me_coasting(3,2) = -1;
   SMT_mB_step(10).abs_me_coasting(5,1) = -1;
   SMT_mB_step(10).abs_me_coasting(5,2) = -1;
   SMT_mB_step(10).abs_me_coasting(7,1) = -1;
   SMT_mB_step(10).abs_me_coasting(7,2) = -1;
   SMT_mB_step(10).abs_me_coasting(8,1) = -1;
   SMT_mB_step(10).abs_me_coasting(8,2) = -1;
   SMT_mB_step(11).abs_me_coasting(1,1) = -1;
   SMT_mB_step(11).abs_me_coasting(1,2) = -1;
   SMT_mB_step(11).abs_me_coasting(3,1) = -1;
   SMT_mB_step(11).abs_me_coasting(3,2) = -1;
   SMT_mB_step(11).abs_me_coasting(5,1) = -1;
   SMT_mB_step(11).abs_me_coasting(5,2) = -1;
   SMT_mB_step(11).abs_me_coasting(7,1) = -1;
   SMT_mB_step(11).abs_me_coasting(7,2) = -1;
   SMT_mB_step(11).abs_me_coasting(8,1) = -1;
   SMT_mB_step(11).abs_me_coasting(8,2) = -1;
   SMT_mB_step(12).abs_me_coasting(1,1) = -1;
   SMT_mB_step(12).abs_me_coasting(1,2) = -1;
   SMT_mB_step(12).abs_me_coasting(3,1) = -1;
   SMT_mB_step(12).abs_me_coasting(3,2) = -1;
   SMT_mB_step(12).abs_me_coasting(5,1) = -1;
   SMT_mB_step(12).abs_me_coasting(5,2) = -1;
   SMT_mB_step(12).abs_me_coasting(7,1) = -1;
   SMT_mB_step(12).abs_me_coasting(7,2) = -1;
   SMT_mB_step(12).abs_me_coasting(8,1) = -1;
   SMT_mB_step(12).abs_me_coasting(8,2) = -1;
   SMT_mB_step(13).abs_me_coasting(1,1) = -1;
   SMT_mB_step(13).abs_me_coasting(1,2) = -1;
   SMT_mB_step(13).abs_me_coasting(3,1) = -1;
   SMT_mB_step(13).abs_me_coasting(3,2) = -1;
   SMT_mB_step(13).abs_me_coasting(5,1) = -1;
   SMT_mB_step(13).abs_me_coasting(5,2) = -1;
   SMT_mB_step(14).abs_me_coasting(1,1) = -1;
   SMT_mB_step(14).abs_me_coasting(1,2) = -1;
   SMT_mB_step(14).abs_me_coasting(3,1) = -1;
   SMT_mB_step(14).abs_me_coasting(3,2) = -1;
   SMT_mB_step(14).abs_me_coasting(5,1) = -1;
   SMT_mB_step(14).abs_me_coasting(5,2) = -1;
   SMT_mB_step(14).abs_me_coasting(7,1) = -1;
   SMT_mB_step(14).abs_me_coasting(7,2) = -1;
   SMT_mB_step(14).abs_me_coasting(8,1) = -1;
   SMT_mB_step(14).abs_me_coasting(8,2) = -1;
   SMT_mB_step(14).abs_me_coasting(10,1) = -1;
   SMT_mB_step(14).abs_me_coasting(10,2) = -1;
   SMT_mB_step(15).abs_me_coasting(1,1) = -1;
   SMT_mB_step(15).abs_me_coasting(1,2) = -1;
   SMT_mB_step(15).abs_me_coasting(3,1) = -1;
   SMT_mB_step(15).abs_me_coasting(3,2) = -1;
   SMT_mB_step(15).abs_me_coasting(5,1) = -1;
   SMT_mB_step(15).abs_me_coasting(5,2) = -1;
   SMT_mB_step(15).abs_me_coasting(7,1) = -1;
   SMT_mB_step(15).abs_me_coasting(7,2) = -1;
   SMT_mB_step(15).abs_me_coasting(8,1) = -1;
   SMT_mB_step(15).abs_me_coasting(8,2) = -1;
   SMT_mB_step(15).abs_me_coasting(10,1) = -1;
   SMT_mB_step(15).abs_me_coasting(10,2) = -1;
   SMT_mB_step(16).abs_me_coasting(1,1) = -1;
   SMT_mB_step(16).abs_me_coasting(1,2) = -1;
   SMT_mB_step(16).abs_me_coasting(3,1) = -1;
   SMT_mB_step(16).abs_me_coasting(3,2) = -1;
   SMT_mB_step(16).abs_me_coasting(5,1) = -1;
   SMT_mB_step(16).abs_me_coasting(5,2) = -1;
   SMT_mB_step(16).abs_me_coasting(6,1) = -1;
   SMT_mB_step(16).abs_me_coasting(6,2) = -1;
   SMT_mB_step(17).abs_me_coasting(1,1) = -1;
   SMT_mB_step(17).abs_me_coasting(1,2) = -1;
   SMT_mB_step(17).abs_me_coasting(3,1) = -1;
   SMT_mB_step(17).abs_me_coasting(3,2) = -1;
   SMT_mB_step(17).abs_me_coasting(5,1) = -1;
   SMT_mB_step(17).abs_me_coasting(5,2) = -1;
   SMT_mB_step(17).abs_me_coasting(6,1) = -1;
   SMT_mB_step(17).abs_me_coasting(6,2) = -1;
   SMT_mB_step(18).abs_me_coasting(1,1) = -1;
   SMT_mB_step(18).abs_me_coasting(1,2) = -1;
   SMT_mB_step(18).abs_me_coasting(3,1) = -1;
   SMT_mB_step(18).abs_me_coasting(3,2) = -1;
   SMT_mB_step(19).abs_me_coasting(1,1) = -1;
   SMT_mB_step(19).abs_me_coasting(1,2) = -1;
   SMT_mB_step(19).abs_me_coasting(3,1) = -1;
   SMT_mB_step(19).abs_me_coasting(3,2) = -1;
   SMT_mB_step(20).abs_me_coasting(1,1) = -1;
   SMT_mB_step(20).abs_me_coasting(1,2) = -1;
   SMT_mB_step(20).abs_me_coasting(3,1) = -1;
   SMT_mB_step(20).abs_me_coasting(3,2) = -1;
   SMT_mB_step(20).abs_me_coasting(5,1) = -1;
   SMT_mB_step(20).abs_me_coasting(5,2) = -1;
   SMT_mB_step(20).abs_me_coasting(7,1) = -1;
   SMT_mB_step(20).abs_me_coasting(7,2) = -1;
   SMT_mB_step(20).abs_me_coasting(9,1) = -1;
   SMT_mB_step(20).abs_me_coasting(9,2) = -1;
   SMT_mB_step(20).abs_me_coasting(10,1) = -1;
   SMT_mB_step(20).abs_me_coasting(10,2) = -1;
   SMT_mB_step(20).abs_me_coasting(12,1) = -1;
   SMT_mB_step(20).abs_me_coasting(12,2) = -1;
   SMT_mB_step(21).abs_me_coasting(1,1) = -1;
   SMT_mB_step(21).abs_me_coasting(1,2) = -1;
   SMT_mB_step(21).abs_me_coasting(3,1) = -1;
   SMT_mB_step(21).abs_me_coasting(3,2) = -1;
   SMT_mB_step(21).abs_me_coasting(5,1) = -1;
   SMT_mB_step(21).abs_me_coasting(5,2) = -1;
   SMT_mB_step(21).abs_me_coasting(7,1) = -1;
   SMT_mB_step(21).abs_me_coasting(7,2) = -1;
   SMT_mB_step(21).abs_me_coasting(9,1) = -1;
   SMT_mB_step(21).abs_me_coasting(9,2) = -1;
   SMT_mB_step(21).abs_me_coasting(10,1) = -1;
   SMT_mB_step(21).abs_me_coasting(10,2) = -1;
   SMT_mB_step(21).abs_me_coasting(12,1) = -1;
   SMT_mB_step(21).abs_me_coasting(12,2) = -1;
   SMT_mB_step(22).abs_me_coasting(1,1) = -1;
   SMT_mB_step(22).abs_me_coasting(1,2) = -1;
   SMT_mB_step(22).abs_me_coasting(3,1) = -1;
   SMT_mB_step(22).abs_me_coasting(3,2) = -1;
   SMT_mB_step(22).abs_me_coasting(5,1) = -1;
   SMT_mB_step(22).abs_me_coasting(5,2) = -1;
   SMT_mB_step(22).abs_me_coasting(7,1) = -1;
   SMT_mB_step(22).abs_me_coasting(7,2) = -1;
   SMT_mB_step(22).abs_me_coasting(9,1) = -1;
   SMT_mB_step(22).abs_me_coasting(9,2) = -1;
   SMT_mB_step(22).abs_me_coasting(10,1) = -1;
   SMT_mB_step(22).abs_me_coasting(10,2) = -1;
   SMT_mB_step(22).abs_me_coasting(12,1) = -1;
   SMT_mB_step(22).abs_me_coasting(12,2) = -1;
   SMT_mB_step(23).abs_me_coasting(1,1) = -1;
   SMT_mB_step(23).abs_me_coasting(1,2) = -1;
   SMT_mB_step(23).abs_me_coasting(3,1) = -1;
   SMT_mB_step(23).abs_me_coasting(3,2) = -1;
   SMT_mB_step(23).abs_me_coasting(5,1) = -1;
   SMT_mB_step(23).abs_me_coasting(5,2) = -1;
   SMT_mB_step(23).abs_me_coasting(7,1) = -1;
   SMT_mB_step(23).abs_me_coasting(7,2) = -1;
   SMT_mB_step(23).abs_me_coasting(9,1) = -1;
   SMT_mB_step(23).abs_me_coasting(9,2) = -1;
   SMT_mB_step(23).abs_me_coasting(10,1) = -1;
   SMT_mB_step(23).abs_me_coasting(10,2) = -1;
   SMT_mB_step(23).abs_me_coasting(12,1) = -1;
   SMT_mB_step(23).abs_me_coasting(12,2) = -1;
   SMT_mB_step(24).abs_me_coasting(1,1) = -1;
   SMT_mB_step(24).abs_me_coasting(1,2) = -1;
   SMT_mB_step(24).abs_me_coasting(3,1) = -1;
   SMT_mB_step(24).abs_me_coasting(3,2) = -1;
   SMT_mB_step(24).abs_me_coasting(5,1) = -1;
   SMT_mB_step(24).abs_me_coasting(5,2) = -1;
   SMT_mB_step(24).abs_me_coasting(7,1) = -1;
   SMT_mB_step(24).abs_me_coasting(7,2) = -1;
   SMT_mB_step(24).abs_me_coasting(8,1) = -1;
   SMT_mB_step(24).abs_me_coasting(8,2) = -1;
   SMT_mB_step(24).abs_me_coasting(10,1) = -1;
   SMT_mB_step(24).abs_me_coasting(10,2) = -1;
   SMT_mB_step(25).abs_me_coasting(1,1) = -1;
   SMT_mB_step(25).abs_me_coasting(1,2) = -1;
   SMT_mB_step(25).abs_me_coasting(3,1) = -1;
   SMT_mB_step(25).abs_me_coasting(3,2) = -1;
   SMT_mB_step(25).abs_me_coasting(5,1) = -1;
   SMT_mB_step(25).abs_me_coasting(5,2) = -1;
   SMT_mB_step(25).abs_me_coasting(7,1) = -1;
   SMT_mB_step(25).abs_me_coasting(7,2) = -1;
   SMT_mB_step(25).abs_me_coasting(8,1) = -1;
   SMT_mB_step(25).abs_me_coasting(8,2) = -1;
   SMT_mB_step(25).abs_me_coasting(10,1) = -1;
   SMT_mB_step(25).abs_me_coasting(10,2) = -1;
   SMT_mB_step(26).abs_me_coasting(1,1) = -1;
   SMT_mB_step(26).abs_me_coasting(1,2) = -1;
   SMT_mB_step(26).abs_me_coasting(3,1) = -1;
   SMT_mB_step(26).abs_me_coasting(3,2) = -1;
   SMT_mB_step(26).abs_me_coasting(5,1) = -1;
   SMT_mB_step(26).abs_me_coasting(5,2) = -1;
   SMT_mB_step(27).abs_me_coasting(1,1) = -1;
   SMT_mB_step(27).abs_me_coasting(1,2) = -1;
   SMT_mB_step(27).abs_me_coasting(3,1) = -1;
   SMT_mB_step(27).abs_me_coasting(3,2) = -1;
   SMT_mB_step(27).abs_me_coasting(5,1) = -1;
   SMT_mB_step(27).abs_me_coasting(5,2) = -1;
   SMT_mB_step(27).abs_me_coasting(6,1) = -1;
   SMT_mB_step(27).abs_me_coasting(6,2) = -1;
return
