function SMT2_Data_Vitesses_mB
 
%-------------------------------------------------------------
%Appel des sous-fonctions pour chaque type d'objet 
%-------------------------------------------------------------
   recup_vitesse_mB;


return
 
 
%***************************************************************
function recup_vitesse_mB
% vitesses missions de base
%***************************************************************
 
   global SMT_donnees_mb_vsecu SMT_nb_donnees_mb_vsecu
   global SMT_donnees_mb_vfonc SMT_nb_donnees_mb_vfonc

   SMT_nb_donnees_mb_vsecu = 0;
   SMT_donnees_mb_vsecu = [ ...
   ];
 
   SMT_nb_donnees_mb_vfonc = 0;
   SMT_donnees_mb_vfonc = [ ...
   ];
 
return
