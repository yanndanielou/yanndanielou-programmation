function SMT2_Data_projet
 
% version de SMT2 compatible
% --------------------------
global SMT_Version_Adonf_SMT2
   SMT_Version_Adonf_SMT2 = 'V7_0.d';
global SMT_Version_Adonf_SMT_ATS_Plus
   SMT_Version_Adonf_SMT_ATS_Plus = 'V7_1.a';

 
% d�termination de la valeur inexistante
% --------------------------------------
global SMT_NA_DBL
   SMT_NA_DBL = -989898989;

%------------------------------------------------------------- 
%Unit�s de saisie des donn�es de voie 
%------------------------------------------------------------- 
   global SMT_units_D SMT_coef_D SMT_units_V SMT_coef_V SMT_langue_anglais SMT_langue_francais SMT_Fic_Donnees SMT_Fic_Macro
   SMT_units_D = 'm';
   SMT_coef_D = 1;
   SMT_units_V = 'km/h';
   SMT_coef_V = 1/3.6;
   SMT_langue_anglais=1;
   SMT_langue_francais=0;
   SMT_Fic_Donnees = 'DC_SYS_SMT3_LV1__ADONF_7_9_d.xlsm';
   SMT_Fic_Macro = 'ADONF TGF_7_9_d du 08/12/2022 15h53';


return
