function SMT2_Data_PC_ATS
 
%-------------------------------------------------------------
%Appel des sous-fonctions pour chaque type d'objet 
%-------------------------------------------------------------
   recup_PC_ATS;


return
 
 
%***************************************************************
function recup_PC_ATS
% Donn�es de voie contenant les informations sur les PC_ATS
%***************************************************************
 
   global SMT_PC_ATS SMT_nb_PC_ATS

   SMT_nb_PC_ATS = 0;

   SMT_PC_ATS = struct( ...
      'nom',{},...
      'seg',{},...
      'Xseg',{});
 
return
