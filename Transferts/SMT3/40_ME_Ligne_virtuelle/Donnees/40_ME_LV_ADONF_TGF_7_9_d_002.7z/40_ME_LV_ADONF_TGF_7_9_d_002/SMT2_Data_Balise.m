function SMT2_Data_Balise
 
%-------------------------------------------------------------
%Appel des sous-fonctions pour chaque type d'objet 
%-------------------------------------------------------------
   recup_balise;


return
 
 
%***************************************************************
function recup_balise
% balises
%***************************************************************
 
   global SMT_balise SMT_nb_balise

   SMT_nb_balise = 0;
   SMT_balise = struct( ...
      'nom',{},...
      'seg',{},...
      'Xseg',{},...
      'num',{},...
      'voie',{},...
      'pk',{}...
      );
 
return
